Based on the last homework's ReadMe.txt, this time we only add -hi to 
the use of these scripts. 

For broker.py, it is the same as the last time. 

For pub.py, if in command window, I input the following: 
python pub.py -t topic0,topic1 -hi 10,20
Then it means this publisher publishes 2 topics, 'topic0' and 'topic1'. 
For 'topic0', it has history of 10. For 'topic1', it has history of 20. 
Again, it publishes a random topic each time. Certainly, you can input 
as many topics as you like. 

For sub.py, how to use it is the same as pub.py. If I input: 
python pub.py -t topic0,topic1 -hi 10,20
Then it means this subscriber subscribe 2 topics, 'topic0' and 'topic1'.
For 'topic0', it has history of 10. For 'topic1', it has history of 20. 
You can input as many topics as you like. 

Test cases are in 2 test_cases folder. 
