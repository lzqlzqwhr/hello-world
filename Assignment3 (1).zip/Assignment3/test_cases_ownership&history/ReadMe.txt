These test cases are mainly testing history scenario. You can run 
broker.py in ahead. 

For history blocking: 
1. You can create a publisher with topic0 (10 history), and a 
subscriber with topic0 (15 history), then you will be able to see the 
subscriber can not receive message. 
2. You can change the publisher's history to 20, and you will be able 
to see the subscriber can receive message now. 

For topic-history binding: 
1. you can create a publisher with topic0 (10 history) and topic1 (15 
history), then you can create a subscriber with topic0 (15 history) 
and topic1 (15 history). And you will be able to see the subscriber can 
receive topic1 but not topic0 

For ownership-history combination: 
You can first create a publisher with topic0 (10 history), then create 
another publisher with topic0 (15 history). Then you can create a 
subscriber with topic0 (15 history). Then you will be able to see 
how "offered vs request" logic works: Despite the first publisher has 
the first ownership, the subscriber still receive message from the 
second publisher. This is because the first one does not have enough 
history. 
