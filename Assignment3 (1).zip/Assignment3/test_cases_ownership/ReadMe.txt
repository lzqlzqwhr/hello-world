This folder tests ownership. You can prepare 6 terminals in advance. 3 
for publishers, 1 for broker1 and 2 for subscribers. In this assignment,
ownership means first come first get. 

1. You can use the command: python broker.py, in order to create the 
first broker.

2. You can use the command: python pub1.py -t topic0 -hi 10, in order 
to create the first publisher with the topic of 'topic0'.

3. You can use the command: python sub.py -t topic0 -hi 10, in order to 
create the first subscriber who wants the topic of 'topic0'. Now you 
will be able to see message being sent from pub to sub.

4. You can use the command: python pub2.py -t topic0,topic1 -hi 10,10, 
in order to create the second publisher with the topics of 'topic0' and 
'topic1'. Now you will be able to notice 1st subscriber don't receive 
anything from 2nd publisher. This is beacause 2nd publisher doesn't 
have ownership of topic0.

5. You can use the command: python sub.py -t topic0,topic1 -hi 10,10, 
in order to create the second subscriber who is interested in 'to+pic0' 
and 'topic1'. And you will be able to see 2nd subscriber can receive 
message of topic1 from 2nd publisher. This is because even though 2nd 
publisher doesn't have ownership of topic0, it has ownership of topic1. 

6. You can use the command: python pub3.py -t topic1 -hi 10, in order 
to create 3rd pubscriber who is interested in 'topic1'. And you will be 
able to see 2nd subscriber can't receive message of 'topic1' from 3rd 
publisher.

7. You can use interrupt 1st publisher's process with control + C. 
After several seconds, 1st subscriber will get message of 'topic0' from 
2nd publisher. This is because once 1st publisher dies, the ownership of
'topic0' transmits to 2nd publisher.

8. You can use interrupt 2nd publisher's process with control + C. 
This time, 1st subscriber will stop reveiving message. However, 2nd sublisher will start receiving message of 'topic1' from 2nd publisher. 

9. You can interrupt 1st subscriber's process with control + C. You 
will be able to see the system keep working.

The above steps should cover all the cases.
