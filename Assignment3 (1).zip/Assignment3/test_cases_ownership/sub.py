from kazoo.client import KazooClient
import zmq
import logging
import time
import argparse

# Logging
logging.basicConfig ()

# Listener
def listener4state (state):
    if state == KazooState.LOST:
        print ("Current state is now = LOST")
    elif state == KazooState.SUSPENDED:
        print ("Current state is now = SUSPENDED")
    elif state == KazooState.CONNECTED:
        print ("Current state is now = CONNECTED")
    else:
        print ("Current state now = UNKNOWN !! Cannot happen")

# Object: sub. Use dealer-router for broker-sub. Each sub has a unique port. /topic_sub directory will store which topic has which sub.
class sub ():
    def __init__ (self, args):
        self.socket = None
        self.zk = None
        self.subID = None
        self.port = None
        self.topics = args.topics.split (',')
        self.history = args.history.split (',')

    def connect_to_zk (self):
        self.zk = KazooClient (hosts='127.0.0.1:2181')
        self.zk.start ()
        self.zk.add_listener (listener4state)
        print (self.zk.state)

    def create_zknode (self):
        n = 0
        if self.zk.exists ('/sub'):
            n = len (self.zk.get_children ('/sub'))    # Count how many children we currently have.
        self.port = 6666 + n
        self.zk.create ('/sub/sub', str.encode (str (self.port)), ephemeral = True, sequence = True, makepath = True)
        self.subID = max (self.zk.get_children ('/sub'))    # subID is the maximum one.

    def create_zmq_socket (self):
        context = zmq.Context ()
        self.socket = context.socket (zmq.ROUTER)
        self.socket.bind ("tcp://*:%s" % self.port)

    def topic_sub_znode (self):
        for i in range (len (self.topics)):
            topic = self.topics [i]
            self.zk.create ('topic_sub/%s/%s' %(topic, self.subID), str.encode (self.history [i]), ephemeral = True, sequence = False, makepath = True)

    def subscribe (self):
        while True:
            self.socket.recv ()
            message = self.socket.recv_string ()
            print('Received message: %s' % message)
            print('Current time is %s' % time.time ())

            time.sleep (1)

    def run (self):
        self.connect_to_zk ()
        print ('Successfully connect zkSever.')

        self.create_zknode ()
        print ('Successfully create znode.')

        self.create_zmq_socket ()
        print ('Successfully created ZMQ socket.')

        self.topic_sub_znode ()
        print ('Successfully connect to SUB port')

        print ('Start subscribing.')
        self.subscribe ()       


def main ():
    parser = argparse.ArgumentParser ()
    parser.add_argument ("-t", "--topics", default = "topic0", help = "Topics")
    parser.add_argument ("-hi", "--history", default = "10", help = "History")
    args = parser.parse_args ()
    
    subscriber = sub (args)
    subscriber.run ()

if __name__ == '__main__':
    main ()

