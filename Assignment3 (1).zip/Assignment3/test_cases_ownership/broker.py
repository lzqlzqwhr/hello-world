from kazoo.client import KazooClient
import zmq
import logging
import time

# Logging
logging.basicConfig ()

# Listener
def listener4state (state):
    if state == KazooState.LOST:
        print ("Current state is now = LOST")
    elif state == KazooState.SUSPENDED:
        print ("Current state is now = SUSPENDED")
    elif state == KazooState.CONNECTED:
        print ("Current state is now = CONNECTED")
    else:
        print ("Current state now = UNKNOWN !! Cannot happen")

# Object: broker. User dealer-router for pub-broker, and pub-sub for broker-sub
class broker ():
    def __init__ (self):
        self.context = zmq.Context ()
        self.socket_IN = None
        self.socket_OUT = {}  # key: port, value: ZMQ PUB socket for that port
        self.port_IN = None
        self.zk = None
        self.brokerID = None

    def connect_to_zk (self):
        self.zk = KazooClient (hosts='127.0.0.1:2181')
        self.zk.start ()
        self.zk.add_listener (listener4state)
        print (self.zk.state)

    def create_zknode (self):
        # Count how many brokers we have so far.
        n = 0
        if self.zk.exists ('/broker'):
            n = len (self.zk.get_children ('/broker'))

        # Each broker has a unique port.
        self.port_IN = 5555 + n    # The port for pub-broker.
        byte = str.encode (str (self.port_IN))    # Convert to byte. Then store it as value for this node in zkServer. 
        self.zk.create ('/broker/broker', byte, ephemeral=True, sequence = True, makepath=True)    # Create its own node in zkServer.
        self.brokerID = max (self.zk.get_children ('/broker'))

    def pub_broker_port (self):
        self.socket_IN = self.context.socket (zmq.ROUTER)
        self.socket_IN.bind ("tcp://*:%s" % self.port_IN)

    def forward_message (self):
        while True:
            # Receive message
            self.socket_IN.recv ()
            message = self.socket_IN.recv ()
            message = bytes.decode (message)  # Bytes => string
            print('Receive message: %s' % message)

            # Forward message
            pubID, topic, content = message.split (',') # Divide message into topic and content
            pub_history = int (bytes.decode (self.zk.get ('/topic_pub/%s/%s' %(topic, pubID)) [0]))    # This is history on pub side.

            # First, we need to check if this publisher has the ownership for this topic, which means we will go to topic_pub/topicID/ directory and check whether this pubID is the smallest one.
            mini_pubID = min (self.zk.get_children ('/topic_pub/%s' %topic))
            
            if pubID == mini_pubID: 
                if self.zk.exists ('/topic_sub/%s' % topic):  # If this directory exists, then we send messages to all of subs which subscribe this topic
                    subIDs = self.zk.get_children ('/topic_sub/%s' % topic)  # These are all subIDs
                    for subID in subIDs:
                        sub_history = self.zk.get ('topic_sub/%s/%s' %(topic, subID))  # This is history on sub side.
                        sub_history = int (bytes.decode (sub_history [0])) 
                        if pub_history >= sub_history:  # If pub's history > sub's history, then forward. Otherwise block.
                            value, stat = self.zk.get ('sub/%s' % subID)
                            port = bytes.decode (value)    # byte => string
                            if port not in self.socket_OUT:    # If this is the first time we meet this port, then we add this port to our socket_OUT dictionary.
                                self.socket_OUT [port] = self.context.socket (zmq.DEALER)
                                self.socket_OUT [port].connect ("tcp://localhost:%s" % port)
                            self.socket_OUT [port].send_string (content)    # Now forward message to that port(sub).
            
            else:  # If It does not have 1st ownership, then we have to compare this one's history with the publishers in front of it.
                pubIDs = self.zk.get_children ('topic_pub/%s' %topic)
                for other_pubID in pubIDs:  # Get all pubs ahead.
                    if other_pubID >= pubID:
                        pubIDs.remove (other_pubID)

                history_list = []  # Get all histories.
                for other_pubID in pubIDs:
                    history_list.append (int (bytes.decode (self.zk.get ('topic_pub/%s/%s' %(topic, other_pubID)) [0])))
                max_history = max (history_list)

                if pub_history > max_history:
                    subIDs = self.zk.get_children ('/topic_sub/%s' % topic)  # These are all subIDs
                    for subID in subIDs:
                        sub_history = self.zk.get ('topic_sub/%s/%s' %(topic, subID)) [0]  # This is history on sub side.
                        sub_history = int (bytes.decode (sub_history)) 
                        if pub_history > sub_history and sub_history > max_history:  # If pub's history > sub's history, then forward. Otherwise block.
                            value, stat = self.zk.get ('sub/%s' % subID)
                            port = bytes.decode (value)    # byte => string
                            if port not in self.socket_OUT:    # If this is the first time we meet this port, then we add this port to our socket_OUT dictionary.
                                self.socket_OUT [port] = self.context.socket (zmq.DEALER)
                                self.socket_OUT [port].connect ("tcp://localhost:%s" % port)
                            self.socket_OUT [port].send_string (content)    # Now forward message to that port(sub).

            time.sleep (1)

    def run (self):
        self.connect_to_zk ()
        print ('Successfully connect zkSever.')

        self.create_zknode ()
        print ('Successfully create znode.')

        self.pub_broker_port ()
        print ('Successfully connected to port.')

        print ('Start forwarding messages.')
        self.forward_message ()


if __name__ == '__main__':
    broker ().run ()


