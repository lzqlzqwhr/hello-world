from kazoo.client import KazooClient
import zmq
import logging
import time
import argparse

# Logging
logging.basicConfig ()

# Listener
def listener4state (state):
    if state == KazooState.LOST:
        print ("Current state is now = LOST")
    elif state == KazooState.SUSPENDED:
        print ("Current state is now = SUSPENDED")
    elif state == KazooState.CONNECTED:
        print ("Current state is now = CONNECTED")
    else:
        print ("Current state now = UNKNOWN !! Cannot happen")

# Object: sub. Use pub-sub for broker-sub. Each topic has a unique port.
class sub ():
    def __init__ (self, args):
        self.context = None
        self.socket = None
        self.zk = None
        self.subID = None
        self.topics = args.topics.split (',')

    def connect_to_zk (self):
        self.zk = KazooClient (hosts='127.0.0.1:2181')
        self.zk.start ()
        self.zk.add_listener (listener4state)
        print (self.zk.state)

    def create_zknode (self):
        self.zk.create ('/sub/sub', b'', ephemeral = True, sequence = True, makepath = True)
        n = len(self.zk.get_children ('/pub'))    # Count how many pubs we have so far
        self.subID = n

    def create_zmq_socket (self):
        self.context = zmq.Context ()
        self.socket = self.context.socket (zmq.SUB)

    def topic_sub_znode (self):
        if not self.zk.exists ('/topic'):  # If not exist, then create
            self.zk.create ('/topic', b'', ephemeral = False, sequence = False, makepath = True)     # topic directory

        for topic in self.topics:
            if not self.zk.exists ('/topic/%s' %topic):  # If this is the first time when we register this topic in zookeeper, then we have to create a new znode for this topic. Then we should open a new port for it, and store the new port as this znode's value.
                n = len (self.zk.get_children ('/topic'))  # Count for how many topics we have so far
                port = 6666 + n  # The port for this topic
                port = str.encode (str (port))  # convert it into bytes
                self.zk.create ('/topic/%s' %topic, port, ephemeral = False, sequence = False, makepath = True)   # Finally, create '/topic/topic'
            else:  # If we have already registered this topic, then we just need read its value, since this is its port.
                value, stat = self.zk.get ('topic/%s' %topic)
                port = value

            # Now we connect sub's socket to the port
            port = bytes.decode (port)  # First we need to convert the port into string
            self.socket.connect ('tcp://localhost:%s' % port)  # Then we can connect
            self.socket.setsockopt_string (zmq.SUBSCRIBE, '')  # Accept all topics, because we implemented above filter mechanism. This is necessary, since by default, ZMQ SUB socket blocks all topics.

            # Finally, let's create children znode for the last layer: '/topic/topic/subID'
            ID = 'sub' + str (self.subID)  # For example, use 'sub1' to represent the first sub
            ID = str.encode (ID)  # Convert ID into byte
            self.zk.create ('/topic/%s/%s' %(topic, ID), ID, ephemeral = True, sequence = True, makepath = True)   # Create '/topic/topic'

    def subscribe (self):
        while True:
            message = self.socket.recv_string ()
            print('Current time is %s' % time.time ())

            time.sleep (1)

    def run (self):
        self.connect_to_zk ()
        print ('Successfully connect zkSever.')

        self.create_zknode ()
        print ('Successfully create znode.')

        self.create_zmq_socket ()
        print ('Successfully created ZMQ socket.')

        self.topic_sub_znode ()
        print ('Successfully connect to SUB port')

        print ('Start subscribing.')
        self.subscribe ()       


def main ():
    parser = argparse.ArgumentParser ()
    parser.add_argument ("-t", "--topics", default = "topic0", help = "Topics")
    args = parser.parse_args ()
    
    subscriber = sub (args)
    subscriber.run ()

if __name__ == '__main__':
    main ()

