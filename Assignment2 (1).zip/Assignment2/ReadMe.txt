For test cases, please go to '/test_cases' directory, For measurement 
and plotting, please go to '/measurement' directory.

This is a guide about how to implement 'pub.py', 'broker.py' and 
'sub.py'. Before you run them, you have to go to your virtual 
environment. For example, for me I have to use command: 
source my_env/bin/activate, in order to work in my virtual environment. 
Then you have to go to current directory. Afterwards, you can run these 3 scripts. For example, if I want to run a  broker, I can use the 
command: python broker.py .

You must run 'broker.py' first, at least once, in order to create a 
broker, and then you can run 'pub.py'. Otherwise, it will give you 
error.

When using 'pub.py', you can use command: python pub.py -t topic0,topic1
, in order to register this publisher with 2 topics, 'topic0' and  
'topic1'. You can register as many topics as you want, not only 2. Each 
time, the script will randomly choose one of its topic and publish 
'content' for this topic. By default, the topic is 'topic0'.

When using 'sub.py', you can use command: python sub.py -t topic0,topic1
, in order to register this publisher with 2 topics, 'topic0' and 
'topic1'. Then this subsriber will receive any content with these 2 
topics. You can register as many topics as you want, not only 2. By 
default, the topic is 'topic0'.
