This contains all test cases. You can prepare 6 hosts in advance. 2 for 
publishers, 2 for brokers and 2 for subscribers.

You can use the following command to open 6 hosts: 
sudo mn --topo tree,depth=3,fanout=2
Then you should run the following command:
xterm h1 h2 h3 h4 h5 h6

Finally you can consider each terminal as a host, and set them in python
environment manually. Then come to this folder. 

1. You can use the command: python broker.py, in order to create the 
first broker.

2. You can use the command: python pub.py -t topic0, in order to create 
the first publisher with the topic of 'topic0'.

3. You can use the command: python sub.py -t topic0, in order to create the first subscriber who wants the topic of 'topic0'. Now you will be 
able to see message being sent from pub to sub.

4. You can use the command: python pub.py -t topic0,topic1, in order to create the second publisher with the topics of 'topic0' and 'topic1'. 
Now you will be able to notice 1st subscriber receive message more 
frequently. This is because 2nd publisher will randomly choose 1 topic 
each time, and publish content of this topic.

5. You can use the command: python sub.py -t topic0,topic1, in order to 
create the second subscriber who are interested in 'topic0' and 
'topic1'. 

6. You can use the command: python broker.py, in order to create 2nd 
broker.

7. You can use interrupt 1st broker's process with control + C. After 
several seconds, 2nd broker will get into use, and the system keep 
running.

8. You can interrupt 1st publisher's process with control + C. You will be able to see the system keep working.

9. You can interrupt 1st subscriber's process with control + C. You 
will be able to see the system keep working.

The above steps should cover all the cases.
