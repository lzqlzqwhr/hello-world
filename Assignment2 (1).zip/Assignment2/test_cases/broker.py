from kazoo.client import KazooClient
import zmq
import logging
import time

# Logging
logging.basicConfig ()

# Listener
def listener4state (state):
    if state == KazooState.LOST:
        print ("Current state is now = LOST")
    elif state == KazooState.SUSPENDED:
        print ("Current state is now = SUSPENDED")
    elif state == KazooState.CONNECTED:
        print ("Current state is now = CONNECTED")
    else:
        print ("Current state now = UNKNOWN !! Cannot happen")

# Object: broker. User dealer-router for pub-broker, and pub-sub for broker-sub
class broker ():
    def __init__ (self):
        self.context = zmq.Context ()
        self.socket_IN = None
        self.socket_OUT = {}  # key: port, value: ZMQ PUB socket for that port
        self.port_IN = None
        self.zk = None
        self.brokerID = None

    def connect_to_zk (self):
        self.zk = KazooClient (hosts='127.0.0.1:2181')
        self.zk.start ()
        self.zk.add_listener (listener4state)
        print (self.zk.state)

    def create_zknode (self):
        # Count how many brokers we have so far.
        n = 0
        if self.zk.exists ('/broker'):
            n = len(self.zk.get_children ('/broker'))
        self.brokerID = n

        # Each broker has a unique port.
        self.port_IN = 5555 + n    # The port for pub-broker.
        byte = str.encode (str (self.port_IN))    # Convert to byte. Then store it as value for this node in zkServer. 
        self.zk.create ('/broker/broker', byte, ephemeral=True, sequence = True, makepath=True)    # Create its own node in zkServer.

    def pub_broker_port (self):
        self.socket_IN = self.context.socket (zmq.ROUTER)
        self.socket_IN.bind ("tcp://*:%s" % self.port_IN)

    def forward_message (self):
        while True:
            # Receive message
            self.socket_IN.recv ()
            message = self.socket_IN.recv ()
            message = bytes.decode (message)  # Bytes => string
            print('Receive message: %s' % message)

            # Forward message
            topic, content = message.split (',') # Divide message into topic and content
            if self.zk.exists ('/topic/%s' % topic):  # If this directory exists, then we send messages to all of subs which subscribe this topic
                value, stat = self.zk.get('/topic/%s' % topic)  # port is its value
                port = bytes.decode (value)  # Byte => string
                if port not in self.socket_OUT:  # If it is the first time when we meet the port, then we add it to our socket_OUT dictionary
                    self.socket_OUT [port] = self.context.socket (zmq.PUB)
                    self.socket_OUT [port].bind ("tcp://*:%s" % port)
                self.socket_OUT [port].send_string (content)

            time.sleep (1)

    def run (self):
        self.connect_to_zk ()
        print ('Successfully connect zkSever.')

        self.create_zknode ()
        print ('Successfully create znode.')

        self.pub_broker_port ()
        print ('Successfully connected to port.')

        print ('Start forwarding messages.')
        self.forward_message ()


if __name__ == '__main__':
    broker ().run ()


