from kazoo.client import KazooClient
import zmq
import logging
import time
import argparse
import random

# Logging
logging.basicConfig ()

# Listener
def listener4state (state):
    if state == KazooState.LOST:
        print ("Current state is now = LOST")
    elif state == KazooState.SUSPENDED:
        print ("Current state is now = SUSPENDED")
    elif state == KazooState.CONNECTED:
        print ("Current state is now = CONNECTED")
    else:
        print ("Current state now = UNKNOWN !! Cannot happen")

# Obect: publisher. Use dealer-router for pub-broker.
class pub ():
    def __init__ (self, args):
        self.context = zmq.Context ()
        self.socket = None
        self.zk = None
        self.pubID = None
        self.topics = args.topics.split (',')

    def connect_to_zk (self):
        self.zk = KazooClient (hosts='127.0.0.1:2181')
        self.zk.start ()
        self.zk.add_listener (listener4state)
        print (self.zk.state)

    def create_zknode (self):
        self.zk.create ('/pub/pub', b'', ephemeral = True, sequence = True, makepath = True)
        n = len (self.zk.get_children ('/pub'))    # Count how many pubs we have so far
        self.pubID = n

    def watch_broker (self):
        @self.zk.ChildrenWatch ('/broker')
        def my_func (children):
            print ("All brokers: %s" % children)    # Show all the brokers
            
            # Search for broker
            brokers = self.zk.get_children ('/broker')
            broker = min (brokers)    # The leader
            value, stat = self.zk.get ('broker/%s' % broker)     # value = port in form of byte. We need decode them to string.
            port = bytes.decode (value) 
            self.socket = self.context.socket (zmq.DEALER)    # Connect to broker
            self.socket.connect ("tcp://localhost:%s" % port)
            
    def publish (self):
        topic = random.choice (self.topics)  # Randomly choose one topic
        content = 'a' * 1000000
        message = topic + ',' + content
        message = str.encode (message)  # Str => byte
        self.socket.send (message)
        print('Current time is %s' % time.time ())

    def run (self):
        self.connect_to_zk ()
        print ('Successfully connect zkSever.')

        self.create_zknode ()
        print ('Successfully create znode.')

        self.watch_broker ()
        print ('Successfully watch broker.')

        print ('Start publishing.')
        self.publish ()


def main ():
    parser = argparse.ArgumentParser ()
    parser.add_argument ("-t", "--topics", default = "topic0", help = "Topics")
    args = parser.parse_args ()
    
    publisher = pub (args)
    publisher.run ()

if __name__ == '__main__':
    main ()

           

