The end-to-end measurement is very much similar to Assignment1. Still 
use 1 pub and 5 subs for measurement. 'pub.py' and 'sub.py' are 
different now. We decide just send message once and see how long does 
it take to finish the process.

You can use the following command to open 6 hosts: 
sudo mn --topo tree,depth=3,fanout=2
Then you should run the following command:
xterm h1 h2 h3 h4 h5 h6

Finally you can consider each terminal as a host, and set them in python
environment manually. Then come to this folder. 

First use 5 terminals to run the same command: python sub.py. Then use 
1 terminals to run the command: python broker.py. Then seperately run 3 
different pub script. pub1 publishes 10KB data, pub2 publishes 100KB 
data and pub3 publishes 1MB data.

We can calculate the time difference and plot. The below is raw data:
		pub1		pub2		pub3
publish		.2684777	.4613624	.0960925
recv1		.2713132	.5350072	.3040617
recv2		.2711344	.5351143	.3062868
recv3		.2712588	.5350668	.3076057
recv4		.2711828	.5348854	.3049948
recv5		.2713630	.5353530	.3095810
