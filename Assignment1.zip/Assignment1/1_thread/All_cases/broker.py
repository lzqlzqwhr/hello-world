import zmq
import time
from collections import defaultdict

context = zmq.Context()
socket = context.socket(zmq.REP)
socket.bind("tcp://*:5555")

pub_city = defaultdict(lambda: set())    # 1 pub can have multiple cities.
city_sub = defaultdict(lambda: set())    # 1 city can have multiple sub.
sub_port = {}    # 1 sub exactly has 1 port.
active_sub = set()    # Keep tracking which sub is active.
i = 1

while True:
    message = socket.recv_string()
    message = message.split(',')    # 0: operation ID

    if message[0] == 'pub_register':    # 1: pub_ID, 2: city
        pub_city[message[1]].add(message[2])
        print('%s register %s' %(message[1], message[2]))
        socket.send_string("Registered successfully.")

    elif message[0] == 'publish':    # 1: city, 2: degree
        for sub_ID in city_sub[message[1]]:    # send it to subscribers.
            if sub_ID in active_sub:
                sub_port[sub_ID].send_string("%s,%s" %(message[1], message[2]))
                sub_port[sub_ID].recv_string()
        
        print('Successfully send info.')
        socket.send_string("published successfully.")

    elif message[0] == 'sub_register':    # 1: sub_ID, 2: city
        addr = 5555 + i    # Define a new address.
        i += 1
        socket.send_string("tcp://*:%s" %addr)    # Send it to subscriber.

        a = context.socket(zmq.REQ)    # Connect to this address.
        a.connect("tcp://localhost:%s" %addr)
        city_sub[message[2]].add(message[1])    # Add this sub into the dictionary.
        sub_port[message[1]] = a    # Give the new address to this sub.
        print("Successfully register %s with %s" %(message[1], message[2]))
        

    elif message[0] == 'notify':    # 1: sub_ID
        active_sub.add(message[1])
        socket.send_string("")
        print("Start send info to %s" %message[0])

    time.sleep(0.1)
