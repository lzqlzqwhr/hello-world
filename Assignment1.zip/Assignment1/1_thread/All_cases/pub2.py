import zmq
import time

context = zmq.Context()
socket = context.socket(zmq.REQ)
socket.connect("tcp://localhost:5555")
pub_ID = 'pub2'
topic = ['Nashville', 'NewYork']

def pub_register(pub_ID, city):
    socket.send_string("pub_register,%s,%s" %(pub_ID, city))
    message = socket.recv_string()
    print(message)


def publish(city, degree):
    print(time.time())
    socket.send_string("publish,%s,%s" %(city, degree))
    message = socket.recv_string()
    print(message)


pub_register(pub_ID, topic[1])
while True:
    publish(topic[1], '40F')

    time.sleep(3)
