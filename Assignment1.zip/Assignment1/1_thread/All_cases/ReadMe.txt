For successfully running thses Python scripts, you should set up Python environment in terminal, and go to the files' directory, then open these files with Python.

It doesn't matter in which order you open these scripts. They will all get run eventually. However, I recommend you to run broker.py first, then open sub1.py and pub1.py. Since so far it is the simplest model of pub-sub, which is 1 pub, 1 broker, 1 sub and 1 topic. And then you can open sub2.py and pub2.py to see how this model works in a more complex case.

pub1.py pulishes only the degree of 'Nashville' and pub2.py publishes only the degree of 'NewYork'. And sub1.py subscribes for the degree of 'Nashville', while sub2.py subscribes for both topics. I believe that this should almost include all the cases that Andy asks, such as 1 sub subscribing many topics, new subs being able to come later and so on.

However, this model does not allow any one to quit once connected. If you press 'control + C' to end any process, the whole system will shut ddown. I believe that this is because of zmq module or client-server model.
