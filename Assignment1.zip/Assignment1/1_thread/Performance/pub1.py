import zmq
import time

context = zmq.Context()
socket = context.socket(zmq.REQ)
socket.connect("tcp://localhost:5555")
pub_ID = 'pub1'
topic = 'Nashville'

f = open('100K.txt', 'r')
data = f.readline()
f.close()

def pub_register(pub_ID, city):
    socket.send_string("pub_register,%s,%s" %(pub_ID, city))
    message = socket.recv_string()
    print(message)


def publish(city, degree):
    print(time.time())
    socket.send_string("publish,%s,%s" %(city, degree))
    message = socket.recv_string()
    print(message)


pub_register(pub_ID, topic)
time.time()
publish(topic, data)
