import zmq
import time

context = zmq.Context()
socket = context.socket(zmq.REQ)
socket.connect("tcp://localhost:5555")
sub_ID = 'sub4'
topic1 = 'Nashville'
topic2 = 'NewYork'

def sub_register(sub_ID, city):

    socket.send_string("sub_register,%s,%s" %(sub_ID, city))    # Send register request.
    message = socket.recv_string()    # Receive address.

    socket1 = context.socket(zmq.REP)    
    socket1.bind(message)    # Bind this address.
    print('Subscribe %s successfully' %city)

    return socket1


def notify(sub_ID, socket1):
    socket.send_string("notify,%s" %sub_ID)
    socket.recv_string()
    print("%s starts receiving" %sub_ID)

    while True:    # Waiting for notifications.
        message = socket1.recv_string().split(',')    # 0: city, 1: degree
        print("Received messsage")   
        socket1.send_string("")

        print(time.time())


socket1 = sub_register(sub_ID, topic1)
notify(sub_ID, socket1)
